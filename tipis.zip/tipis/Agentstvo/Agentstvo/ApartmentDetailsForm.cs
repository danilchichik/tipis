﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Net;

namespace Agentstvo
{
    public partial class ApartmentDetailsForm : Form
    {
        public ApartmentDetailsForm()
        {
            InitializeComponent();
        }

        private int apartmentId;

    public ApartmentDetailsForm(int id)
    {
        InitializeComponent();
        apartmentId = id;
        LoadApartmentDetails();
    }

    private void LoadApartmentDetails()
    {
        using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
      
        {
            string query = "SELECT title, address, price, Description, photopath FROM Apartments WHERE Id = @id";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", apartmentId);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                lblTitle.Text = reader["Title"].ToString();
                lblAddress.Text = reader["Address"].ToString();
                lblPrice.Text = "Цена: " + Convert.ToDecimal(reader["Price"]).ToString("C");
                txtDescription.Text = reader["Description"].ToString();
            }
            if (reader["photopath"] != DBNull.Value)
            {
                string imagePath = reader["photopath"].ToString();

                try
                {
                    // Если это путь к локальному файлу
                    if (File.Exists(imagePath))
                    {
                        pictureBoxPhoto.Image = Image.FromFile(imagePath);
                    }
                    // Или если это URL (ссылка в интернете)
                    else if (imagePath.StartsWith("http"))
                    {
                        using (WebClient wc = new WebClient())
                        {
                            byte[] bytes = wc.DownloadData(imagePath);
                            using (MemoryStream ms = new MemoryStream(bytes))
                            {
                                pictureBoxPhoto.Image = Image.FromStream(ms);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки изображения: " + ex.Message);
                }
            }
        }
       

    }

        private void ApartmentDetailsForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            RequestForm requestForm = new RequestForm(apartmentId); 
            requestForm.ShowDialog();
        }
    }

}
