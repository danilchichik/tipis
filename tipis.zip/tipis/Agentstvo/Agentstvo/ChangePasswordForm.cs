﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Agentstvo
{
    public partial class ChangePasswordForm : Form
    {
        private int _userId;
        
        public ChangePasswordForm(int userId)
        {
            InitializeComponent();
            _userId = userId;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string oldPass = txtOldPassword.Text;
            string newPass = txtNewPassword.Text;
            string confirmPass = txtConfirmPassword.Text;

            if (newPass != confirmPass)
            {
                MessageBox.Show("Новый пароль и подтверждение не совпадают.");
                return;
            }

            if (string.IsNullOrEmpty(newPass))
            {
                MessageBox.Show("Введите новый пароль.");
                return;
            }

            // Проверяем старый пароль в базе
            if (!CheckOldPassword(_userId, oldPass))
            {
                MessageBox.Show("Старый пароль неверен.");
                return;
            }

            // Обновляем пароль в базе
            if (UpdatePassword(_userId, newPass))
            {
                MessageBox.Show("Пароль успешно изменён.");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Ошибка при изменении пароля.");
            }
        }
        private bool CheckOldPassword(int userId, string oldPass)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
                {
                    conn.Open();
                    string sql = "SELECT COUNT(*) FROM Users WHERE UserID = @UserID AND password = @Password";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@UserID", userId);
                        cmd.Parameters.AddWithValue("@Password", oldPass);

                        int count = (int)cmd.ExecuteScalar();
                        return count > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        private bool UpdatePassword(int userId, string newPass)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
                {
                    conn.Open();
                    string sql = "UPDATE Users SET password = @Password WHERE UserID = @UserID";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@Password", newPass);
                        cmd.Parameters.AddWithValue("@UserID", userId);

                        int rows = cmd.ExecuteNonQuery();
                        return rows > 0;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
