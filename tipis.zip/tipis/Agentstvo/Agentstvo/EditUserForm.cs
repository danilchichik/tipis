﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Agentstvo
{
    public partial class EditUserForm : Form
    {
        public EditUserForm()
        {
            InitializeComponent();
        }
        private User _user;

    public EditUserForm(User user)
    {
        InitializeComponent();
        _user = user;

        // Заполняем поля формы данными пользователя
        txtFirstName.Text = _user.FirstName;
        txtLastName.Text = _user.LastName;
        txtMiddleName.Text = _user.MiddleName;
        txtPhone.Text = _user.Phone;
        txtEmail.Text = _user.Email;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        // Обновляем данные в объекте User
        _user.FirstName = txtFirstName.Text.Trim();
        _user.LastName = txtLastName.Text.Trim();
        _user.MiddleName = txtMiddleName.Text.Trim();
        _user.Phone = txtPhone.Text.Trim();
        _user.Email = txtEmail.Text.Trim();

        // Сохраняем изменения в базе
        if (UpdateUserInDatabase(_user))
        {
            MessageBox.Show("Данные успешно обновлены.");
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        else
        {
            MessageBox.Show("Ошибка при обновлении данных.");
        }
    }

    private bool UpdateUserInDatabase(User user)
    {
        try
        {
            using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
            {
                conn.Open();
                string sql = @"UPDATE Users SET 
                    firstName = @FirstName, 
                    lastName = @LastName, 
                    middleName = @MiddleName, 
                    phone = @Phone, 
                    email = @Email
                    WHERE UserID = @UserID";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@FirstName", user.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", user.LastName);
                    cmd.Parameters.AddWithValue("@MiddleName", user.MiddleName);
                    cmd.Parameters.AddWithValue("@Phone", user.Phone);
                    cmd.Parameters.AddWithValue("@Email", user.Email);
                    cmd.Parameters.AddWithValue("@UserID", user.UserID);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(string.Format("Ошибка при сохранении: {0}", ex.Message));
            return false;
        }
    }
        private void EditUserForm_Load(object sender, EventArgs e)
        {

        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
