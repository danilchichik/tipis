﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Agentstvo
{

        public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            
        }

        private User GetUserByLoginAndPassword(string username, string password)
        {
            User user = null;

            using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
            {
                conn.Open();

                string sql = @"SELECT UserID, username, firstName, lastName, middleName, phone, email
                       FROM Users 
                       WHERE username = @username AND password = @password";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            user = new User
                            {
                                UserID = reader.GetInt32(0),
                                Username = reader.GetString(1),
                                FirstName = reader.GetString(2),
                                LastName = reader.GetString(3),
                                MiddleName = reader.IsDBNull(4) ? null : reader.GetString(4),
                                Phone = reader.IsDBNull(5) ? null : reader.GetString(5),
                                Email = reader.IsDBNull(6) ? null : reader.GetString(6)
                            };
                        }
                    }
                }
            }

            return user;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            User user = GetUserByLoginAndPassword(username, password);
            if (user == null)
            {
                MessageBox.Show("Неверный логин или пароль");
                return;
            }

            UserForm profileForm = new UserForm(user);
            profileForm.Show();

            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
        public class User
        {
            public int UserID { get; set; }
            public string Username { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string MiddleName { get; set; }
            public string Phone { get; set; }
            public string Email { get; set; }
        }
}
