﻿namespace Agentstvo
{
    partial class UserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabApartments = new System.Windows.Forms.TabPage();
            this.btnFilter = new System.Windows.Forms.Button();
            this.rdoRent = new System.Windows.Forms.RadioButton();
            this.rdoBuy = new System.Windows.Forms.RadioButton();
            this.txtMaxPrice = new System.Windows.Forms.TextBox();
            this.cmbDistrict = new System.Windows.Forms.ComboBox();
            this.cmbRooms = new System.Windows.Forms.ComboBox();
            this.flowLayoutApartments = new System.Windows.Forms.FlowLayoutPanel();
            this.BtnDetails = new System.Windows.Forms.Button();
            this.BtnRequest = new System.Windows.Forms.Button();
            this.tabRequests = new System.Windows.Forms.TabPage();
            this.tabProfile = new System.Windows.Forms.TabPage();
            this.btnResetFilter = new System.Windows.Forms.Button();
            this.flowLayoutPanelCards = new System.Windows.Forms.FlowLayoutPanel();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.btnEditProfile = new System.Windows.Forms.Button();
            this.btnChangePassword = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabApartments.SuspendLayout();
            this.flowLayoutApartments.SuspendLayout();
            this.tabRequests.SuspendLayout();
            this.tabProfile.SuspendLayout();
            this.flowLayoutPanelCards.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabApartments);
            this.tabControl1.Controls.Add(this.tabRequests);
            this.tabControl1.Controls.Add(this.tabProfile);
            this.tabControl1.Location = new System.Drawing.Point(1, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(678, 816);
            this.tabControl1.TabIndex = 0;
            // 
            // tabApartments
            // 
            this.tabApartments.BackColor = System.Drawing.Color.DodgerBlue;
            this.tabApartments.Controls.Add(this.btnResetFilter);
            this.tabApartments.Controls.Add(this.btnFilter);
            this.tabApartments.Controls.Add(this.rdoRent);
            this.tabApartments.Controls.Add(this.rdoBuy);
            this.tabApartments.Controls.Add(this.txtMaxPrice);
            this.tabApartments.Controls.Add(this.cmbDistrict);
            this.tabApartments.Controls.Add(this.cmbRooms);
            this.tabApartments.Controls.Add(this.flowLayoutApartments);
            this.tabApartments.Location = new System.Drawing.Point(4, 22);
            this.tabApartments.Name = "tabApartments";
            this.tabApartments.Padding = new System.Windows.Forms.Padding(3);
            this.tabApartments.Size = new System.Drawing.Size(670, 790);
            this.tabApartments.TabIndex = 0;
            this.tabApartments.Text = "Подборка квартир";
            // 
            // btnFilter
            // 
            this.btnFilter.BackColor = System.Drawing.Color.Transparent;
            this.btnFilter.Location = new System.Drawing.Point(390, 31);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(138, 21);
            this.btnFilter.TabIndex = 6;
            this.btnFilter.Text = "Применить фильтр";
            this.btnFilter.UseVisualStyleBackColor = false;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // rdoRent
            // 
            this.rdoRent.AutoSize = true;
            this.rdoRent.Location = new System.Drawing.Point(152, 31);
            this.rdoRent.Name = "rdoRent";
            this.rdoRent.Size = new System.Drawing.Size(69, 20);
            this.rdoRent.TabIndex = 5;
            this.rdoRent.TabStop = true;
            this.rdoRent.Text = "Аренда";
            this.rdoRent.UseVisualStyleBackColor = true;
            this.rdoRent.CheckedChanged += new System.EventHandler(this.rdoRent_CheckedChanged);
            // 
            // rdoBuy
            // 
            this.rdoBuy.AutoSize = true;
            this.rdoBuy.Location = new System.Drawing.Point(152, 8);
            this.rdoBuy.Name = "rdoBuy";
            this.rdoBuy.Size = new System.Drawing.Size(75, 20);
            this.rdoBuy.TabIndex = 4;
            this.rdoBuy.TabStop = true;
            this.rdoBuy.Text = "Покупка";
            this.rdoBuy.UseVisualStyleBackColor = true;
            this.rdoBuy.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // txtMaxPrice
            // 
            this.txtMaxPrice.Location = new System.Drawing.Point(262, 9);
            this.txtMaxPrice.Name = "txtMaxPrice";
            this.txtMaxPrice.Size = new System.Drawing.Size(100, 20);
            this.txtMaxPrice.TabIndex = 3;
            // 
            // cmbDistrict
            // 
            this.cmbDistrict.FormattingEnabled = true;
            this.cmbDistrict.Location = new System.Drawing.Point(3, 31);
            this.cmbDistrict.Name = "cmbDistrict";
            this.cmbDistrict.Size = new System.Drawing.Size(121, 21);
            this.cmbDistrict.TabIndex = 2;
            // 
            // cmbRooms
            // 
            this.cmbRooms.FormattingEnabled = true;
            this.cmbRooms.Location = new System.Drawing.Point(3, 7);
            this.cmbRooms.Name = "cmbRooms";
            this.cmbRooms.Size = new System.Drawing.Size(121, 21);
            this.cmbRooms.TabIndex = 1;
            this.cmbRooms.SelectedIndexChanged += new System.EventHandler(this.cmbRooms_SelectedIndexChanged);
            // 
            // flowLayoutApartments
            // 
            this.flowLayoutApartments.AutoScroll = true;
            this.flowLayoutApartments.BackColor = System.Drawing.Color.White;
            this.flowLayoutApartments.Controls.Add(this.BtnDetails);
            this.flowLayoutApartments.Controls.Add(this.BtnRequest);
            this.flowLayoutApartments.ForeColor = System.Drawing.Color.Black;
            this.flowLayoutApartments.Location = new System.Drawing.Point(6, 58);
            this.flowLayoutApartments.Name = "flowLayoutApartments";
            this.flowLayoutApartments.Size = new System.Drawing.Size(658, 729);
            this.flowLayoutApartments.TabIndex = 0;
            this.flowLayoutApartments.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutApartments_Paint);
            // 
            // BtnDetails
            // 
            this.BtnDetails.BackColor = System.Drawing.Color.Transparent;
            this.BtnDetails.Location = new System.Drawing.Point(3, 3);
            this.BtnDetails.Name = "BtnDetails";
            this.BtnDetails.Size = new System.Drawing.Size(75, 23);
            this.BtnDetails.TabIndex = 0;
            this.BtnDetails.Text = "button1";
            this.BtnDetails.UseVisualStyleBackColor = false;
            this.BtnDetails.Click += new System.EventHandler(this.BtnDetails_Click);
            // 
            // BtnRequest
            // 
            this.BtnRequest.BackColor = System.Drawing.Color.Transparent;
            this.BtnRequest.ForeColor = System.Drawing.Color.Black;
            this.BtnRequest.Location = new System.Drawing.Point(84, 3);
            this.BtnRequest.Name = "BtnRequest";
            this.BtnRequest.Size = new System.Drawing.Size(75, 23);
            this.BtnRequest.TabIndex = 1;
            this.BtnRequest.Text = "button2";
            this.BtnRequest.UseVisualStyleBackColor = false;
            this.BtnRequest.Click += new System.EventHandler(this.BtnRequest_Click);
            // 
            // tabRequests
            // 
            this.tabRequests.BackColor = System.Drawing.Color.DodgerBlue;
            this.tabRequests.Controls.Add(this.btnRefresh);
            this.tabRequests.Controls.Add(this.flowLayoutPanelCards);
            this.tabRequests.Location = new System.Drawing.Point(4, 22);
            this.tabRequests.Name = "tabRequests";
            this.tabRequests.Padding = new System.Windows.Forms.Padding(3);
            this.tabRequests.Size = new System.Drawing.Size(670, 790);
            this.tabRequests.TabIndex = 1;
            this.tabRequests.Text = "Заявки";
            this.tabRequests.Click += new System.EventHandler(this.tabRequests_Click);
            // 
            // tabProfile
            // 
            this.tabProfile.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabProfile.Controls.Add(this.btnChangePassword);
            this.tabProfile.Controls.Add(this.btnEditProfile);
            this.tabProfile.Controls.Add(this.lblEmail);
            this.tabProfile.Controls.Add(this.lblPhone);
            this.tabProfile.Controls.Add(this.lblFullName);
            this.tabProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabProfile.Location = new System.Drawing.Point(4, 22);
            this.tabProfile.Name = "tabProfile";
            this.tabProfile.Padding = new System.Windows.Forms.Padding(3);
            this.tabProfile.Size = new System.Drawing.Size(670, 790);
            this.tabProfile.TabIndex = 2;
            this.tabProfile.Text = "Личный кабинет";
            this.tabProfile.Click += new System.EventHandler(this.tabProfile_Click);
            // 
            // btnResetFilter
            // 
            this.btnResetFilter.BackColor = System.Drawing.Color.Transparent;
            this.btnResetFilter.Location = new System.Drawing.Point(534, 31);
            this.btnResetFilter.Name = "btnResetFilter";
            this.btnResetFilter.Size = new System.Drawing.Size(130, 21);
            this.btnResetFilter.TabIndex = 7;
            this.btnResetFilter.Text = "Сбросить фильтр";
            this.btnResetFilter.UseVisualStyleBackColor = false;
            this.btnResetFilter.Click += new System.EventHandler(this.btnResetFilter_Click);
            // 
            // flowLayoutPanelCards
            // 
            this.flowLayoutPanelCards.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanelCards.Controls.Add(this.BtnDelete);
            this.flowLayoutPanelCards.Location = new System.Drawing.Point(7, 41);
            this.flowLayoutPanelCards.Name = "flowLayoutPanelCards";
            this.flowLayoutPanelCards.Size = new System.Drawing.Size(657, 743);
            this.flowLayoutPanelCards.TabIndex = 0;
            // 
            // BtnDelete
            // 
            this.BtnDelete.BackColor = System.Drawing.Color.Transparent;
            this.BtnDelete.Font = new System.Drawing.Font("Times New Roman", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDelete.Location = new System.Drawing.Point(3, 3);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(75, 23);
            this.BtnDelete.TabIndex = 0;
            this.BtnDelete.Text = "button1";
            this.BtnDelete.UseVisualStyleBackColor = false;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.Transparent;
            this.btnRefresh.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnRefresh.Location = new System.Drawing.Point(515, 0);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(152, 35);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "Обновить страницу";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // lblFullName
            // 
            this.lblFullName.AutoSize = true;
            this.lblFullName.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lblFullName.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFullName.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblFullName.Location = new System.Drawing.Point(32, 36);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(87, 32);
            this.lblFullName.TabIndex = 0;
            this.lblFullName.Text = "label1";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPhone.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPhone.Location = new System.Drawing.Point(32, 107);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(87, 32);
            this.lblPhone.TabIndex = 1;
            this.lblPhone.Text = "label2";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblEmail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblEmail.Location = new System.Drawing.Point(32, 181);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(87, 32);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "label3";
            // 
            // btnEditProfile
            // 
            this.btnEditProfile.BackColor = System.Drawing.Color.LightCyan;
            this.btnEditProfile.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEditProfile.Location = new System.Drawing.Point(7, 676);
            this.btnEditProfile.Name = "btnEditProfile";
            this.btnEditProfile.Size = new System.Drawing.Size(214, 108);
            this.btnEditProfile.TabIndex = 3;
            this.btnEditProfile.Text = "Изменить данные пользователя";
            this.btnEditProfile.UseVisualStyleBackColor = false;
            this.btnEditProfile.Click += new System.EventHandler(this.btnEditProfile_Click);
            // 
            // btnChangePassword
            // 
            this.btnChangePassword.BackColor = System.Drawing.Color.LightCyan;
            this.btnChangePassword.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnChangePassword.Location = new System.Drawing.Point(499, 676);
            this.btnChangePassword.Name = "btnChangePassword";
            this.btnChangePassword.Size = new System.Drawing.Size(165, 108);
            this.btnChangePassword.TabIndex = 4;
            this.btnChangePassword.Text = "Изменить пароль";
            this.btnChangePassword.UseVisualStyleBackColor = false;
            this.btnChangePassword.Click += new System.EventHandler(this.btnChangePassword_Click);
            // 
            // UserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 819);
            this.Controls.Add(this.tabControl1);
            this.Name = "UserForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LuxEstate";
            this.Load += new System.EventHandler(this.UserForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabApartments.ResumeLayout(false);
            this.tabApartments.PerformLayout();
            this.flowLayoutApartments.ResumeLayout(false);
            this.tabRequests.ResumeLayout(false);
            this.tabProfile.ResumeLayout(false);
            this.tabProfile.PerformLayout();
            this.flowLayoutPanelCards.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabApartments;
        private System.Windows.Forms.TabPage tabRequests;
        private System.Windows.Forms.TabPage tabProfile;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutApartments;
        private System.Windows.Forms.Button BtnDetails;
        private System.Windows.Forms.Button BtnRequest;
        private System.Windows.Forms.RadioButton rdoRent;
        private System.Windows.Forms.RadioButton rdoBuy;
        private System.Windows.Forms.TextBox txtMaxPrice;
        private System.Windows.Forms.ComboBox cmbDistrict;
        private System.Windows.Forms.ComboBox cmbRooms;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.Button btnResetFilter;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelCards;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnChangePassword;
        private System.Windows.Forms.Button btnEditProfile;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblFullName;
    }
}