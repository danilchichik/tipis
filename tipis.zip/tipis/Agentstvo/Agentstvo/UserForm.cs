﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Agentstvo
{
    public partial class UserForm : Form
    {

        public UserForm()
        {
            InitializeComponent();
        }

        

        private void LoadApartmentsFiltered()
{
    flowLayoutApartments.Controls.Clear();

    using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
    {
        conn.Open();

        string query = "SELECT * FROM Apartments WHERE 1=1";
        List<SqlParameter> parameters = new List<SqlParameter>();

        if (cmbRooms.SelectedItem != null)
        {
            string selectedRooms = cmbRooms.SelectedItem.ToString();
            if (selectedRooms == "5+")
            {
                query += " AND Rooms >= 5";
            }
            else
            {
                query += " AND Rooms = @Rooms";
                parameters.Add(new SqlParameter("@Rooms", int.Parse(selectedRooms)));
            }
        }

        if (cmbDistrict.SelectedItem != null)
        {
            query += " AND District = @District";
            parameters.Add(new SqlParameter("@District", cmbDistrict.SelectedItem.ToString()));
        }

        decimal maxPrice;
        if (!string.IsNullOrWhiteSpace(txtMaxPrice.Text) && decimal.TryParse(txtMaxPrice.Text, out maxPrice))
        {
            query += " AND Price <= @MaxPrice";
            parameters.Add(new SqlParameter("@MaxPrice", maxPrice));
        }

        if (rdoBuy.Checked)
            query += " AND dealType = 'Buy'";
        else if (rdoRent.Checked)
            query += " AND dealType = 'Rent'";

        SqlCommand cmd = new SqlCommand(query, conn);
        cmd.Parameters.AddRange(parameters.ToArray());

        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            Panel panel = new Panel
            {
                Width = 300,
                Height = 125,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(5)
            };

           string title = reader["Title"].ToString();
string address = reader["Address"].ToString();
decimal price = Convert.ToDecimal(reader["Price"]);

Label lblTitle = new Label
{
    Text = title,
    AutoSize = true,
    Font = new Font("Segoe UI", 10, FontStyle.Bold),
    Location = new Point(10, 10)
};

Label lblAddress = new Label
{
    Text = address,
    AutoSize = true,
    Location = new Point(10, lblTitle.Bottom + 5)
};

Label lblPrice = new Label
{
    Text = price + " руб.",
    AutoSize = true,
    Location = new Point(10, lblAddress.Bottom + 5)
};
            
            Button btnDetails = new Button
            {
                Text = "Подробнее",
                Tag = reader["Id"],
                Location = new Point(10, 90)
            };
            Button btnRequest = new Button
            {
                Text = "Подать заявку",
                Tag = reader["Id"],
                Location = new Point(110, 90),
                Width = 100
            };
            btnRequest.Click += BtnRequest_Click;
            panel.Controls.Add(btnRequest);

            btnDetails.Click += BtnDetails_Click;

            panel.Controls.Add(lblTitle);
            panel.Controls.Add(lblAddress);
            panel.Controls.Add(lblPrice);
            panel.Controls.Add(btnDetails);
            flowLayoutApartments.Controls.Add(panel);
        }
    }
}


        private void LoadApartments()
{
    flowLayoutApartments.Controls.Clear();

    using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
    {
        string query = "SELECT id, title, address, price FROM Apartments";
        SqlCommand cmd = new SqlCommand(query, conn);
        conn.Open();
        SqlDataReader reader = cmd.ExecuteReader();

        while (reader.Read())
        {
            int id = reader.GetInt32(0);
            string title = reader.GetString(1);
            string address = reader.GetString(2);
            decimal price = reader.GetDecimal(3);

            Panel card = new Panel
            {
                Width = 300,
                Height = 150,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(10)
            };

            Label lblTitle = new Label { Text = title, AutoSize = true, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            Label lblAddress = new Label { Text = address, AutoSize = true };
            Label lblPrice = new Label { Text = price.ToString(), AutoSize = true };

            Button btnDetails = new Button { Text = "Подробнее", Width = 100, Tag = id };
            Button btnRequest = new Button { Text = "Подать заявку", Width = 100, Tag = id };

            btnDetails.Click += BtnDetails_Click;
            btnRequest.Click += BtnRequest_Click;

            FlowLayoutPanel buttonPanel = new FlowLayoutPanel();
            buttonPanel.Controls.Add(btnDetails);
            buttonPanel.Controls.Add(btnRequest);

            card.Controls.Add(lblTitle);
            card.Controls.Add(lblAddress);
            card.Controls.Add(lblPrice);
            card.Controls.Add(buttonPanel);

            lblTitle.Top = 10;
            lblAddress.Top = 30;
            lblPrice.Top = 50;
            buttonPanel.Top = 80;

            card.Controls.SetChildIndex(lblTitle, 0);
            flowLayoutApartments.Controls.Add(card);
        }
    }
}

        private void BtnDetails_Click(object sender, EventArgs e)
        {
            
    int apartmentId = (int)((Button)sender).Tag;
    ApartmentDetailsForm detailsForm = new ApartmentDetailsForm(apartmentId);
    detailsForm.ShowDialog();
        }

        private void BtnRequest_Click(object sender, EventArgs e)
        {
            int apartmentId = (int)((Button)sender).Tag;
            RequestForm requestForm = new RequestForm(apartmentId);
            requestForm.ShowDialog();
        }



        private void flowLayoutApartments_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UserForm_Load(object sender, EventArgs e)
        {
            LoadApartments();
            cmbRooms.Items.AddRange(new string[] { "1", "2", "3", "4", "5+" });
            cmbDistrict.Items.AddRange(new string[] { "Sovetskiy", "Kirovskiy", "Oktyabrskiy" });
            LoadRequests();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            LoadApartmentsFiltered();
        }

        private void cmbRooms_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnResetFilter_Click(object sender, EventArgs e)
        {
            txtMaxPrice.Text = "";
            rdoBuy.Checked = false;
            rdoRent.Checked = false;

            LoadApartments();
        }

        private void rdoRent_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void tabRequests_Click(object sender, EventArgs e)
        {

        }

        private Panel CreateRequestCard(int requestId, int apartmentId, string username, DateTime requestDate)
        {
            Panel card = new Panel
            {
                Width = 350,
                Height = 120,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(5)
            };

            Label lblApartment = new Label
            {
                Text = "Apartment ID: " + apartmentId,
                Location = new Point(10, 10),
                AutoSize = true
            };

            Label lblUsername = new Label
            {
                Text = "Username: " + username,
                Location = new Point(10, 35),
                AutoSize = true
            };

            Label lblDate = new Label
            {
                Text = "Request Date: " + requestDate.ToString("dd.MM.yyyy"),
                Location = new Point(10, 60),
                AutoSize = true
            };

            Button btnDelete = new Button
            {
                Text = "Удалить",
                Location = new Point(240, 80),
                Size = new Size(90, 25),
                Tag = requestId // Чтобы знать, какую заявку удалять
            };
            btnDelete.Click += BtnDelete_Click;

            card.Controls.Add(lblApartment);
            card.Controls.Add(lblUsername);
            card.Controls.Add(lblDate);
            card.Controls.Add(btnDelete);

            return card;
        }

        public class Request
        {
            public int RequestID { get; set; }
            public int ApartmentID { get; set; }
            public string Username { get; set; }
            public DateTime RequestDate { get; set; }
        }

        private List<Request> GetRequestsFromDatabase()
        {
            List<Request> list = new List<Request>();

            using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
            {
                conn.Open();

                string sql = "SELECT RequestID, apartmentID, username, requestdate FROM Requests";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Request req = new Request
                            {
                                RequestID = reader.GetInt32(0),
                                ApartmentID = reader.GetInt32(1),
                                Username = reader.GetString(2),
                                RequestDate = reader.GetDateTime(3)
                            };

                            list.Add(req);
                        }
                    }
                }
            }

            return list;
        }

        private void DeleteRequestFromDatabase(int requestId)
        {
            using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
            {
                conn.Open();

                string sql = "DELETE FROM Requests WHERE RequestID = @RequestID";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@RequestID", requestId);
                    int affected = cmd.ExecuteNonQuery();

                    if (affected == 0)
                        throw new Exception("Заявка не найдена.");
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                int requestIdToDelete = (int)btn.Tag;

                try
                {
                    DeleteRequestFromDatabase(requestIdToDelete);

                    Panel card = btn.Parent as Panel;
                    if (card != null)
                    {
                        flowLayoutPanelCards.Controls.Remove(card);
                        card.Dispose();
                    }

                    MessageBox.Show("Заявка удалена.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении заявки: " + ex.Message);
                }
            }
        }


        private void LoadRequests()
        {
            flowLayoutPanelCards.Controls.Clear();

            List<Request> requests = GetRequestsFromDatabase();

            foreach (Request r in requests)
            {
                Panel card = CreateRequestCard(r.RequestID, r.ApartmentID, r.Username, r.RequestDate);
                flowLayoutPanelCards.Controls.Add(card);
            }
        }


        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadRequests();
        }

                       
        private User GetUserByLoginAndPassword(string username, string password)
        {
            User user = null;

            using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.АгентствоConnectionString))
            {
                conn.Open();

                string sql = @"SELECT UserID, username, firstName, lastName, middleName, phone, email
                       FROM Users 
                       WHERE username = @username AND password = @password";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            user = new User
                            {
                                UserID = reader.GetInt32(0),
                                Username = reader.GetString(1),
                                FirstName = reader.GetString(2),
                                LastName = reader.GetString(3),
                                MiddleName = reader.GetString(4),
                                Phone = reader.GetString(5),
                                Email = reader.GetString(6)
                            };
                        }
                    }
                }
            }

            return user;
        }

       private User _user;

    public UserForm(User user)
    {
        InitializeComponent();
        _user = user;
        ShowUserData();
    }

    private void ShowUserData()
    {
        lblFullName.Text = _user.LastName + " " + _user.FirstName + " " + _user.MiddleName;
        lblPhone.Text = "Номер телефона: " + _user.Phone;
        lblEmail.Text = "Email: " + _user.Email;
    }

                      
        private void tabProfile_Click(object sender, EventArgs e)
        {

        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            ChangePasswordForm passForm = new ChangePasswordForm(_user.UserID);
            passForm.ShowDialog();
        }

        private void btnEditProfile_Click(object sender, EventArgs e)
        {
            EditUserForm editForm = new EditUserForm(_user);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                ShowUserData(); // обновить отображаемые данные
            }
        }
        
    }

}
